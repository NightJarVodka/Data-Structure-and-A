/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Q5;

import java.util.Scanner;

/**
 *
 * @author Qiuhuai Wang
 * id: 17971027
 * By passing inputing the String to check which one is missing the bracket
 */
public class Create 
{
    public static void main(String[] args) throws Exception
    {
        
       System.out.println("Please write a String code");
       Scanner input = new Scanner(System.in);
       String sentence = input.next();
       
       //give four various records of brackets 
       int token1 = 0;
       int token2 = 0;
       int token3 = 0;
       int token4 = 0;
      
       // could not be empty
       if(sentence.isEmpty())
       {
           System.out.println("You should print something!");
       }
       else
       {
           for(int i = 0; i < sentence.length() ; ++i)
           {
               //check and record number of appearing
               if(sentence.charAt(i) == '[')
               {
                   token1++;
               }
               else if(sentence.charAt(i) == '{')
               {
                   token2++;
               }
               else if(sentence.charAt(i) == '(')
               {
                   token3++;
               }
               else if(sentence.charAt(i) == '<')
               {
                   token4++;
               }
               else if(sentence.charAt(i) == ']')
               {
                   token1--;
               }
               else if(sentence.charAt(i) == '}')
               {
                   token2--;
               }
               else if(sentence.charAt(i) == ')')
               {
                   token3--;
               }
               else if(sentence.charAt(i) == '>')
               {
                   token4--;
               }
               
               
           }
           
           //distinguish differenet brackets 
           if(token1 == 0 && token2 == 0 && token3 == 0 && token4==0)
           {
               System.out.println("This String will evaluate successfully");
           }
           else
           {
               System.out.println("This String is missing bracket");
               if(token1 !=0)
               {
                   System.out.println("Missing in []");
               }
               
               if(token2 !=0)
               {
                   System.out.println("Missing in {}");
               }
               
               if(token3 !=0)
               {
                   System.out.println("Missing in ()");
               }
               
               if(token4 !=0)
               {
                   System.out.println("Missing in <>");
               }
           }
       }
       
       input.close();
       
    }
}
