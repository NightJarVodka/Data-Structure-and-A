/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Gui;

/**
 *
 * @author Qiuhuai Wang
 * id: 17971027
 */
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

class MachineTemperatureException extends RuntimeException 
{
    
}

public class Machine implements Runnable 
{

    private boolean isRunning;
    private int minTemp;
    private int maxTemp;
    private int currentTemp;
    private Cooler connectedCooler;
    private final Object connectedCoolerLock;
    

    private Thread newThread;

    public Machine(int minTemp, int maxTemp) {
        this.minTemp = minTemp;
        this.maxTemp = maxTemp;
        this.currentTemp = 20; // room temperature
        this.connectedCoolerLock = new Object();
    }

    public void startMachine() {
        this.isRunning = true;
        this.newThread = new Thread(this);
        this.newThread.start();
    }

    public boolean isRunning() {
        return this.isRunning;
    }

    public void stopMachine() {
        this.newThread.stop();
        this.isRunning = false;
    }

    public int getCurrentTemp() {
        return this.currentTemp;
    }

    public int getMinTemp() {
        return this.minTemp;
    }

    public int getMaxTemp() {
        return this.maxTemp;
    }

    public boolean connectCooler(Cooler cooler) {
        synchronized (this.connectedCoolerLock) {
            if (this.connectedCooler == null) {
                this.connectedCooler = cooler;
                return true;
            }
            return false;
        }
    }

    public Cooler getConnectedCooler() {
        synchronized (this.connectedCoolerLock) {
            return connectedCooler;
        }
    }
    
    public boolean isCoolerConnected() {
        synchronized (this.connectedCoolerLock) {

            return this.connectedCooler != null;
        }
    }

    public void disconnectCooler() {
        synchronized (this.connectedCoolerLock) {
            this.connectedCooler.disconnect();
            this.connectedCooler = null;
        }
    }

    @Override
    public void run() throws MachineTemperatureException 
    {
        Timer t = new Timer("update temperature");
        t.scheduleAtFixedRate(new TimerTask() 
        {
            @Override
            public void run() 
            {

                if (!isRunning) 
                {
                    return;
                }
                synchronized (connectedCoolerLock) 
                {
                    if (connectedCooler == null) 
                    {
                        Random random = new Random();
                        currentTemp += random.nextInt(6);
                        if (currentTemp > maxTemp) 
                        {
                            isRunning = false;
                            throw new MachineTemperatureException();
                        }
                    } 
                    else 
                    {
                        currentTemp -= connectedCooler.getCoolingFactor();
                        if (currentTemp < minTemp) 
                        {
                            isRunning = false;
                            throw new MachineTemperatureException();
                        }
                    }
                }

            }
        }, 0, 200);
    }
}
