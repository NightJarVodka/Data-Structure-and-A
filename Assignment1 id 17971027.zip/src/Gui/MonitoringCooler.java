/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Gui;

import java.util.Collection;
import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author Qiuhuai Wang
 * id: 17971027
 */

public class MonitoringCooler implements Cooler, Runnable {

    private final Collection<Machine> machines;
    private final int coolingFactor;
    private boolean isConnected;
    private final Object isConnectedLock;
    private Thread newThread;

    public MonitoringCooler(Collection<Machine> machines, int coolingFactor) {
        this.machines = machines;
        this.coolingFactor = coolingFactor;

        this.isConnected = false;
        this.isConnectedLock = new Object();
    }

    public void startCooler() {
        this.newThread = new Thread(this);
        this.newThread.start();
    }

    public void requestStop() {
        this.newThread.stop();
    }

    public boolean isIsConnected() {
        synchronized (this.isConnectedLock) {
            return isConnected;
        }
    }

    @Override
    public void disconnect() {
        synchronized (this.isConnectedLock) {
            isConnected = false;
        }
    }

    @Override
    public int getCoolingFactor() {
        return coolingFactor;
    }

    @Override
    public boolean isConnectedToMachine() {
        synchronized (this.isConnectedLock) {
            return isConnected;
        }
    }

    @Override
    public void run() {
        Timer t = new Timer("update temperature");
        Cooler c = this;
        t.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                synchronized (isConnectedLock) {
                    for (Machine machine : machines) {
                        // ignore stopped machines
                        if (!machine.isRunning()) {
                            continue;
                        }

                        
                        if (machine.isCoolerConnected()) {
                            if (machine.getConnectedCooler() == c && machine.getCurrentTemp() < machine.getMinTemp() + DANGER_ZONE) {
                                // disconnect almost overcool machines
                                machine.disconnectCooler();
                            }
                        } else if (machine.getCurrentTemp() > machine.getMaxTemp() - DANGER_ZONE
                                && !isConnected) {
                            // connect to overheat machines
                            machine.connectCooler(c);
                        }
                    }
                }
            }
        }, 0, 20);

    }

}
