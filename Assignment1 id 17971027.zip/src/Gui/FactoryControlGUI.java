/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Gui;

/**
 *
 * @author Qiuhuai Wang
 * id: 17971027
 */
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

//create a GUI pattern
public class FactoryControlGUI extends JPanel {

    private boolean isRunning;
    private final int MACHINE_TOTAL = 63;
    private final int COOLER_TOTAL = 55;
    private final int COOLING_FACTOR = 25;
    private final int MIN_TEMP = 0;
    private final int MAX_TEMP = 250;
    private ArrayList<Machine> machines;
    private ArrayList<MonitoringCooler> coolers;

    private JRadioButton radioStart;
    private JRadioButton radioStop;
    private ButtonGroup radioGroup;

    public FactoryControlGUI() {
        super();
        
        this.initMachinesAndCoolers();
        
        setPreferredSize(new Dimension(800, 650));
        this.setLayout(null);

        isRunning = false;

        radioGroup = new ButtonGroup();
        radioStart = new JRadioButton("Start");
        radioStart.setBounds(300, 40, 80, 30);
        radioStop = new JRadioButton("Stop");
        radioStop.setSelected(isRunning);
        radioStop.setBounds(400, 40, 80, 30);
        radioGroup.add(radioStart);
        radioGroup.add(radioStop);
        add(radioStart);
        add(radioStop);

        radioStart.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startRunning();
                radioStop.setSelected(false);
            }
        });
        radioStop.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                stopRunning();
                radioStart.setSelected(false);
            }
        });

        JLabel title = new JLabel("GRAPH OF MACHINES TEMPERATURES IN C");
        title.setBounds(250, 20, 300, 30);
        add(title);

        // need to add a timer
        Timer t = new Timer("repaint");
        t.scheduleAtFixedRate(new TimerTask() {
            public void run() {
                if (isRunning) {
                    repaint();
                }
            }
        }, 200, 200);
      
    }


    public void initMachinesAndCoolers() {
        machines = new ArrayList<Machine>();
        coolers = new ArrayList<MonitoringCooler>();

        for (int i = 0; i < MACHINE_TOTAL; i++) {
            machines.add(new Machine(MIN_TEMP, MAX_TEMP));
        }

        for (int i = 0; i < COOLER_TOTAL; i++) {
            coolers.add(new MonitoringCooler(machines, COOLING_FACTOR));
        }
    }

    public void startRunning() {
        this.isRunning = true;
        for (int i = 0; i < MACHINE_TOTAL; i++) {
            machines.get(i).startMachine();
        }
        for (int i = 0; i < COOLER_TOTAL; i++) {
            coolers.get(i).startCooler();
        }
    }

    public void stopRunning() {
        for (int i = 0; i < MACHINE_TOTAL; i++) {
            machines.get(i).stopMachine();
        }
        for (int i = 0; i < COOLER_TOTAL; i++) {
            coolers.get(i).requestStop();
        }
        isRunning = false;
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        this.paintLines(g);
        this.paintMachines(g);
    }

    public void paintLines(Graphics g) {
        g.setColor(Color.BLACK);
        g.drawLine(0, 100, 770, 100);
        g.drawString("250", 775, 105);

        g.setColor(Color.RED);
        g.drawLine(0, 200, 770, 200);
        g.drawString("200", 775, 205);

        g.setColor(Color.BLACK);
        g.drawLine(0, 350, 770, 350);
        g.drawString("125", 775, 355);

        g.setColor(Color.BLUE);
        g.drawLine(0, 500, 770, 500);
        g.drawString("50", 775, 505);

        g.setColor(Color.BLACK);
        g.drawLine(0, 600, 770, 600);
        g.drawString("0", 775, 605);
    }

    public void paintMachines(Graphics g) {
        for (int i = 0; i < MACHINE_TOTAL; i++) {
            Machine machine = machines.get(i);
            int currentTemp = machine.getCurrentTemp();

            Color color;
            if (currentTemp < 50) {
                color = Color.BLUE;
            } else if (currentTemp < 200) {
                color = Color.YELLOW;
            } else {
                color = Color.RED;
            }

            g.setColor(color);
            g.fillRect(5 + 12 * i, 600 - currentTemp * 2, 10, currentTemp * 2);
            g.setColor(Color.BLACK);
            if (this.isRunning) {
                String sign = machine.isCoolerConnected() ? "+" : "-";
                g.drawString(sign, i * 12 + 5, 610);
            }
        }
    }

    //control it
    public static void main(String[] args) {
        JFrame frame = new JFrame("GRAPH OF MACHINES, BEING COOLED");
        // kill all threads when frame closes
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(new FactoryControlGUI());
        frame.pack();
        // position the frame in the middle of the screen
        Toolkit tk = Toolkit.getDefaultToolkit();
        Dimension screenDimension = tk.getScreenSize();
        Dimension frameDimension = frame.getSize();
        frame.setLocation((screenDimension.width - frameDimension.width) / 2,
                (screenDimension.height - frameDimension.height) / 2);
        frame.setVisible(true);
    }
}

