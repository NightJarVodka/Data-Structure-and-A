/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Q4;

/**
 *
 * @author Qiuhuai Wang
 * id 17971027
 */
public class ArrayDeque 
{
    // make some examples of array
    public static void main(String[] args)
    {
        Test<String> array = new Test<String>();
   
        array.enqueueRear("A");
        array.enqueueRear("N");
        System.out.println(array.toString());
        array.enqueueRear("B");
        array.enqueueRear("H");
        array.enqueueRear("Z");
        array.enqueueRear("Z");
        System.out.println(array.toString());
        array.dequeueFront();
        System.out.println(array.toString());
        array.enqueueRear("B");
        System.out.println(array.toString());
        
        array.enqueueRear("H");
        System.out.println(array.toString());
        System.out.println(array.first());
        System.out.println(array.last());
        
        System.out.println(array.size());
        
        array.clear();
        System.out.println(array.toString());
        
        
    }
   
   
    
}
