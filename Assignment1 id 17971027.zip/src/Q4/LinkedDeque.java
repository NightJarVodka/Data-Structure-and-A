/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Q4;

/**
 *
 * @author Qiuhuai Wang
 * id: 17971027
 */
public class LinkedDeque 
{
//    make some examples of linkedlist
     public static void main(String[] args)
    {
        Test<String> link = new Test<String>();
        
        link.enqueueFront("A");
        link.enqueueFront("N");
        System.out.println(link.toString());
        link.enqueueFront("B");
        link.enqueueFront("H");
        link.enqueueFront("Z");
        link.enqueueFront("Z");
        System.out.println(link.toString());
        link.dequeueRear();
        System.out.println(link.toString());
        
        link.enqueueFront("K");
        System.out.println(link.toString());
        
        System.out.println(link.first());
        System.out.println(link.last());
        
        System.out.println(link.size());
        
        System.out.println(link.iterator().hasNext());
        
        link.clear();
        System.out.println(link.toString());
    }
}
