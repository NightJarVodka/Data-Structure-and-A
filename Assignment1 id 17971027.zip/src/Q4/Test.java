/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Q4;

import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 *
 * @author Qiuhuai Wang
 * id: 17971027
 */
public class Test<E> implements DequeADT<E>
{
    private final int INITIAL_CAPACITY =5;
    protected int numElements;
    protected E[] elements;
    private Node<E> head;
    private Node<E> tail;
    
    public Test()
    {
        super();
        numElements = 0;
        elements = (E [])(new Object[INITIAL_CAPACITY]);
        this.head = null;
        this.tail = null;
    }
    
    public Test(Collection<? extends E> c)
    {
        this();
        for(E element : c)
        {
            enqueueRear(element);
            enqueueFront(element);
        }
    }
    
    // Array in the end
    public void enqueueRear(E element)
    {
        //check is it empty
       if(isEmpty())
       {
           elements[0] = element;
           numElements++;
       }
       else
       {
           if(numElements >= elements.length)
           {
               expandCapacity();
           }
           elements[numElements++] = element;
       }
    }
    
    //array ,减掉后，最后面的来填补前面的空缺
    public E dequeueFront() throws NoSuchElementException
    {
        if(!isEmpty())
        {
            E topElement = elements[numElements -1];
            elements[numElements - 1] = null;
            numElements--;
            return topElement;
        }
        else
        {
            throw new NoSuchElementException();
        }
    }
    
    public E first()throws NoSuchElementException
    {
//        return head;
        if(numElements > 0)
        {
            if(elements[0] != null)
            {
                return elements[0];
            }
            else
            {
                //linked
                return head.element;
            }
            
        }
        else
        {
            throw new NoSuchElementException();
        }
    }
    
    public E last()throws NoSuchElementException
    {
        if(!isEmpty())
        {
            if(elements[0] != null)
            {
                return elements[numElements-1];
            }
            else
            {
                return tail.element;
            }
            
        }
        else
        {
            throw new NoSuchElementException();
        }
//        return tail;
    }
    
    //Linked
    public void enqueueFront(E element)
    {
        Node<E> newNode = new Node<E>(element);
        
        
        if(isEmpty())
        {
            head = newNode;
            tail = newNode;
        }
        else
        {
//            if(numElements >= elements.length)
//           {
//               expandCapacity();
//           }
//            
            newNode.next = head;
            head = newNode;
        }
        
        numElements++;
    }
    
    //linked, deleted and the next will return forward
    public E dequeueRear()throws NoSuchElementException
    {
        if(!isEmpty())
        {
            E topElement = head.element;
            head = head.next;
            numElements--;
            if(numElements == 0)
            {
                head = null;
            }
            return topElement;
        }
        else
        {
            throw new NoSuchElementException();
        }
    }
    
    public boolean isEmpty()
    {
        return (numElements == 0);
    }
    
    public int size()
    {
        return numElements;
    }
    
    //linkedIterator 
    public Iterator<E> iterator()
    {
        return new LinkedIterator<E>(head);
    }
    
    //Array
    public void clear()
    {
        for(int i = numElements ;i > 0; --i)
        {
            if(elements[0] != null)
            {
                elements[i] = null;
            }
            else
            {  
                head = null;
                tail = null;
            }
        }
        elements[0] = null;
        numElements = 0;
    }
    
    private class Node<E>
    {
        public E element;
        public Node<E> next;
        
        public Node(E element)
        {
            this.element = element;
            next = null;
        }
    }
    
    private void expandCapacity()
    {
        E[] largerArray = (E[])(new Object[elements.length*2]);
        
        for(int i=0; i< numElements ;++i)
        {
            largerArray[i] = elements[i];
        }
        
        elements = largerArray;
    }
    
    //link
    private class LinkedIterator<E> implements Iterator<E>
    {
        private Node<E> nextNode;
    
        public LinkedIterator(Node<E> head)
        {
            nextNode = head;
        }
        
        public boolean hasNext()
        {
            return (nextNode != null);
        }
        
        public E next() throws NoSuchElementException
        {
            if(!hasNext())
            {
                throw new NoSuchElementException();
            }
            
            E num = nextNode.element;
            nextNode = nextNode.next;
            return num;
        }
        
        public void remove() throws UnsupportedOperationException
        {
            throw new UnsupportedOperationException();
        }
    }
    
    //Both need toString
    public String toString()
    {
        String output = "[";
        Node currentNode = head;
        if(elements[0]!= null)
        {
            
            //Array
            for(int i = 0 ; i < elements.length ; ++i)
            {
                output += elements[i];
                if(i>=0 && i< elements.length -1)
                {
                    output += ",";
                }
            
            }
        }
        else
        {
            //Linked
            while(currentNode != null)
            {
                output += currentNode.element;
                if(currentNode.next != null)
                {
                    output += ",";
                }
                currentNode =  currentNode.next;
            } 
            
        }
        output += "]";
        return output;
    }
}
